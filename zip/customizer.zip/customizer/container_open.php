<div class="<?=$settings->container_open_class; ?>">
