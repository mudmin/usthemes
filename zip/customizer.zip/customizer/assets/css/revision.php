<?php
// This file is automatically updated by the processor.php script
// Do not edit manually

$css_revision = 'custom-bootstrap-20250309115047.css';
$child_themes = array (
  'dashboard' => 'dashboard-20250302105752.css',
  'child2' => 'child2-20250302104936.css',
);
