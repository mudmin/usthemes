<div id="page-wrapper">
  <!-- feel free to change between container or container fluid -->
  <div class="container">
<style media="screen">
html,
body {
  margin: 0;
  height: 100%;
}

.wrapper {
  box-sizing: border-box;
  position: relative;
  padding-bottom: 1em; /* Height of footer */
  min-height: 100%;
}



footer {
  position: absolute;
  bottom: 0;
  width: 100%;
  color: #fff;
  background-color: #212121 !important;
}
</style>
<?php include "color_override.php";?>
