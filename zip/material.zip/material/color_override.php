<style media="screen">
/* override footer bg color */
footer {
  background-color: #212121 !important;
}

/* override footer text color */
footer.page-footer .footer-copyright {
  color: white !important;
}


.navbar {
  background-color: #212121  !important;

}
</style>
